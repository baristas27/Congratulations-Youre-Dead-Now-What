using System.Collections.Generic;

using UnityEngine;

public class SoulManager : MonoBehaviour
{
    [Header("Daily shift data")]
    public List<SoulData> dailySouls;

    private Queue<SoulData> soulQueue;

    [SerializeField] private PlayerPresentationStateMachine presentationStateMachine;

    public SoulData CurrentSoul { get; private set; }

    [Header("Prefab & Spawn")]
    [SerializeField] private GameObject soulPrefab;
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private Transform windowPoint;

    [Header("Dialogue")]
    [SerializeField] private SoulDialogueController dialogueController;

    [Header("Case File")]
    [SerializeField] private CaseFileUIController caseFileUI;

    [Header("Debug")]
    [SerializeField] private bool destroyPreviousOnSpawn = true;

    private GameObject currentSoulInstance;
    private SoulMover currentSoulMover;

    private void Start()
    {
        InitializeQueue();
        SpawnNextSoul();
    }

    private void InitializeQueue()
    {
        soulQueue = new Queue<SoulData>();

        if (dailySouls != null)
        {
            foreach (SoulData soul in dailySouls)
            {
                soulQueue.Enqueue(soul);
            }
        }

        Debug.Log($"{nameof(SoulManager)}: Queue initialized. Souls waiting: " + soulQueue.Count);
    }

    [ContextMenu("Spawn Next Soul")]
    public void SpawnNextSoul()
    {
        CleanupCurrentSoul();
        if (soulPrefab == null || spawnPoint == null || windowPoint == null)
        {
            Debug.LogWarning($"{nameof(SoulManager)}: Prefab, SpawnPoint or WindowPoint is missing!", this);
            return;
        }

        if (soulQueue == null || soulQueue.Count == 0)
        {
            Debug.Log("The shift is over. No more souls in the waiting room.", this);
            // TODO: Gece vardiyas�na ge�i� burada tetiklenecek.
            return;
        }

        if (destroyPreviousOnSpawn && currentSoulInstance != null)
        {
            Destroy(currentSoulInstance);
            currentSoulInstance = null;
        }

        CurrentSoul = soulQueue.Dequeue();

        currentSoulInstance = Instantiate(soulPrefab, spawnPoint.position, spawnPoint.rotation);

        var appearance = currentSoulInstance.GetComponent<SoulAppearance>();
        if (appearance != null)
        {
            appearance.ApplySoulVisuals(CurrentSoul);
        }
        else
        {
            Debug.LogWarning($"{nameof(SoulManager)}: Spawned prefab has no SoulAppearance component.", currentSoulInstance);
        }

        var mover = currentSoulInstance.GetComponent<SoulMover>();
        if (mover != null)
        {
            currentSoulMover = mover;
            currentSoulMover.OnDestinationReached += HandleSoulArrived;

            
            mover.MoveTo(windowPoint);
        }
        else
        {
            Debug.LogWarning($"{nameof(SoulManager)}: Spawned prefab has no SoulMover component.", currentSoulInstance);
        }
    }

    private void HandleSoulArrived()
    {
        // Safety: Eğer mover hala bağlıysa event'i hemen kaldır
        if (currentSoulMover != null)
        {
            currentSoulMover.OnDestinationReached -= HandleSoulArrived;
        }

        if (CurrentSoul == null)
        {
            Debug.LogWarning($"{nameof(SoulManager)}: HandleSoulArrived called but CurrentSoul is null.", this);
            return;
        }

        if (dialogueController == null)
        {
            Debug.LogWarning($"{nameof(SoulManager)}: DialogueController is not assigned.", this);
            return;
        }

        // Ruh pencereye geldi, artık diyalog başlatabiliriz
        dialogueController.StartDialogue(
            CurrentSoul.introDialogueSegments,
            OnDialogueFinished
        );
    }

    private void OnDialogueFinished()
    {
        if (caseFileUI == null)
        {
            Debug.LogWarning($"{nameof(SoulManager)}: caseFileUI is not assigned. Cannot open case file.", this);
            return;
        }
        presentationStateMachine.EnterUIInteraction();
        caseFileUI.Open(CurrentSoul, HandleVerdict);
    }

    /// <summary>
    /// Called by CaseFileUIController when the player presses Heaven or Hell.
    /// sentToHeaven is true for Heaven, false for Hell.
    /// </summary>
    private void HandleVerdict(bool sentToHeaven)
    {
        if (CurrentSoul == null) return;

        bool isCorrect = sentToHeaven == CurrentSoul.belongsInHeaven;
        string verdictLabel = sentToHeaven ? "Heaven" : "Hell";
        string resultLabel = isCorrect ? "CORRECT" : "INCORRECT";

        Debug.Log($"[Verdict] {CurrentSoul.soulName} sent to {verdictLabel}. Result: {resultLabel}");

        caseFileUI.Close();
        presentationStateMachine.EnterDeskFocus();
        SpawnNextSoul();
    }

    [ContextMenu("Reset Day Souls")]
    public void ResetDaySouls()
    {
        InitializeQueue();

        if (currentSoulInstance != null)
        {
            Destroy(currentSoulInstance);
            currentSoulInstance = null;
        }

        Debug.Log($"{nameof(SoulManager)}: Reset completed.", this);
    }

    private void CleanupCurrentSoul()
    {
        if(currentSoulMover != null)
        {
            currentSoulMover.OnDestinationReached -= HandleSoulArrived;
            currentSoulMover = null;
        }

        if(destroyPreviousOnSpawn && currentSoulInstance != null)
        {
            Destroy(currentSoulInstance);
            currentSoulInstance = null;
        }
    }
}