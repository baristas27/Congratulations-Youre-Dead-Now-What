using UnityEngine;

// Bu scripti m�h�r, kalem, dosya gibi t�m tutulabilir nesnelere ekleyece�iz.
public class PickupItem : MonoBehaviour, IPickable
{
    private Rigidbody rb;

    private void Awake()
    {
        // Component Caching
        rb = GetComponent<Rigidbody>();
    }

    // IPickable aray�z�nden gelen zorunlu metodlar
    public void OnPickedUp()
    {
        Debug.Log(gameObject.name + " tutuldu.");
        // �leride buraya e�ya tutuldu�unda ��kacak bir "h���rt�" sesi ekleyebiliriz.
    }

    public void OnDropped()
    {
        Debug.Log(gameObject.name + " b�rak�ld�.");
        // E�ya b�rak�ld���nda fiziksel k�s�tlamalar� kald�r�yoruz
        rb.constraints = RigidbodyConstraints.None;
    }
}